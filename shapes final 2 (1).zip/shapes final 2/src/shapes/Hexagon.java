/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package shapes;

/**
 *
 * @author madinakhurova
 */
public class Hexagon extends Shapes {
    public Hexagon(double x, double y, double length)
    {
         super("H", x, y, length);
                
    }
    
    
    @Override
    public double MinY() {
        return y - (length * Math.sqrt(3) / 2);
    }
    
    @Override
    public double MaxY() {
        return y + (length * Math.sqrt(3) / 2);
    }
    
    @Override
    public double MinX() {
        return x - length; //for square
    }
    @Override
    public double MaxX() {
        return x + length;
    }
    
    
    
}
