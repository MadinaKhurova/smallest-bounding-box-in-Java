/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package shapes;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author madinakhurova
 */
public class Database {
    private final ArrayList<Shapes> shapes;

    public Database() {
        shapes = new ArrayList<>();
    }

    public void read(String filename) throws FileNotFoundException, InvalidInputException {
        Scanner sc = new Scanner(new BufferedReader(new FileReader(filename)));
        int numShapes = sc.nextInt();
        while (sc.hasNext()) {
            Shapes shape;
            switch (sc.next()) {
                case "C":
                    shape = new Circle(sc.nextDouble(), sc.nextDouble(), sc.nextDouble());
                    break;
                case "H":
                    shape = new Hexagon(sc.nextDouble(), sc.nextDouble(), sc.nextDouble());
                    break;
                case "S":
                    shape = new Square(sc.nextDouble(), sc.nextDouble(), sc.nextDouble());
                    break;
                case "T":
                    shape = new Triangle(sc.nextDouble(), sc.nextDouble(), sc.nextDouble());
                    break;
                default:
                    throw new InvalidInputException();
            }
            
            shapes.add(shape);
        }
    }
    
    public void report() {
        System.out.println("Shapes in the database");
        for (Shapes v : shapes) {
            System.out.println(v.toString());
        }
       
    }

    public String result() {
        double minX = Double.MAX_VALUE;
        double maxX = Double.MIN_VALUE;
        double minY = Double.MAX_VALUE;
        double maxY = Double.MIN_VALUE;

        for (Shapes shape : shapes) {
            minX = Math.min(minX, shape.MinX());
            maxX = Math.max(maxX, shape.MaxX());
            minY = Math.min(minY, shape.MinY());
            maxY = Math.max(maxY, shape.MaxY());
        }
        return "min: ("+ minX +", " + minY +" ), max: "+ maxX+ ", "+ maxY+" )";
    }
    public void readShape(Shapes shape) {
        shapes.add(shape);
    }
    
    public void clear() {
        shapes.clear();
    }
}
