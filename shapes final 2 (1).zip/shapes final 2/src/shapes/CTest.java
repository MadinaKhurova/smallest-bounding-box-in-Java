package shapes;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class CTest {

    @Test
    public void testMinX() {
        Circle circle = new Circle(1, 1, 3);
        assertEquals(-2, circle.MinX());
    }

    @Test
    public void testMaxX() {
        Circle circle = new Circle(3, 5, 4);
        assertEquals(7.0, circle.MaxX());
    }
}

