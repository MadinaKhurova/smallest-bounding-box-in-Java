package shapes;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;


public class TShapes {

    @Test
    public void testMinBox() {
        Circle circle = new Circle(1, 1, 3);
        Square square = new Square(2,3,4);
        Database database = new Database();

        database.readShape(circle);
        database.readShape(square);
        String result = "min: ("+ -2.0 +", " + -2.0 +" ), max: "+ 4.0+ ", "+ 5.0+" )";
        assertEquals(result, database.result());

    }



}

