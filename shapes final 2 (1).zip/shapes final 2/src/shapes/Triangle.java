/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package shapes;

/**
 *
 * @author madinakhurova
 */
public class Triangle extends Shapes {
   public Triangle(double x, double y, double length)
   {
           super("T",x, y, length);
   }
   @Override
   public double MinX()
   {
       return x - length/2;
   }
   @Override
   public double MaxX()
   {
       return x + length/2;
   }
   @Override
   public double MaxY()
   {
       return x + Math.sqrt(3)*length/4;
   }
   @Override
   public double MinY()
   {
       return x - Math.sqrt(3)*length/4;
   }
   
   
}
