/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package shapes;

/**
 *
 * @author madinakhurova
 */
public class Circle extends Shapes {
    public Circle(double x, double y, double length)
    {
        super("C", x, y, length);
    }
    
    @Override
    public double MinX() {
        return x - length;
    }
    @Override
    public double MinY() {
        return y - length;
    } 
    
    @Override
    public double MaxY() {
        return y + length;
    }
    
    @Override
    public double MaxX() {
        return x + length;
    }
    
    
}
