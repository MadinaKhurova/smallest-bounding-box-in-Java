package shapes;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class STest {

    @Test
    public void testMinX() {
        Square a = new Square(1, 1, 4);
        assertEquals(-1, a.MinX());
    }

    @Test
    public void testMaxX() {
        Square a = new Square(1, 1, 4);
        assertEquals(3, a.MaxX());
    }
}

