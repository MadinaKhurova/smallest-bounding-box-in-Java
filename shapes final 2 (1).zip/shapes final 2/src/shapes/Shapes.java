/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package shapes;

/**
 *
 * @author madinakhurova
 */
public abstract class Shapes {

    /**
     * @param args the command line arguments
     */
    
    String category;
    double x;
    double y;
    double length;

    public Shapes(String category, double x, double y, double length) {
        this.category = category;
        this.x = x;
        this.y = y;
        this.length = length;
    }
    public double MinX()
    {
        return x - length/2; //for square
    }
    public double MaxX()
    {
        return x + length/2;
    }
    public double MinY()
    {
        return y - length/2;
    }
    public double MaxY()
    {
        return y + length/2;
    }
    
    @Override
    public String toString() {
        return "Shape{ category= " + category + ", length/radius=" + length + ", center= (" + x +','+ y+ ")}";
    }

    Object getCategory() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    

    


    
    
}
