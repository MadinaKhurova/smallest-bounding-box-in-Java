/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package shapes;

/**
 *
 * @author madinakhurova
 */
public class Square extends Shapes{
    public Square(double x, double y, double length)
    {
        super("S", x, y, length);
    }

}
